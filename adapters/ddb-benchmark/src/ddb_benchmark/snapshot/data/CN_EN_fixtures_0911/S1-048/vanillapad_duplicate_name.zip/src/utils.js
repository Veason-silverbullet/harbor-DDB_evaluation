export function formatLabel(value) {
  return `Duplicate fixture: ${value}`;
}
