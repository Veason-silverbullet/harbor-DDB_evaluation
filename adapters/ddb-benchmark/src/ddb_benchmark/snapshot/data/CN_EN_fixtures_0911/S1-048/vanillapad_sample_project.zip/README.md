# VanillaPad Fixture Project

A small offline project used to test project import, file-tree rendering, and dependency parsing.
