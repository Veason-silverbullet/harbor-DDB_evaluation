import { formatLabel } from './utils.js';
import { render } from './render.js';

render(document.querySelector('#vp-output'), formatLabel('fixture ready'));
