import './utils.js';

export function render(target, label) {
  target.textContent = label;
}
