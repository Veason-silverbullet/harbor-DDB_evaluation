export function formatLabel(value) {
  return `VanillaPad ${value}`;
}
